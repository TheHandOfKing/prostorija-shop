<?php

include_once 'header.php';
include_once 'footer.php';
include_once 'auth.php';
include_once 'checkout.php';
include_once 'home.php';
include_once 'shop.php';