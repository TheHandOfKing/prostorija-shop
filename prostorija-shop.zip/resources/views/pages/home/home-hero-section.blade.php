<section class="home-hero-section">
  <div class="content">
    <h1>Prostorija shop</h1>
    <div class="category-holder">
      <div class="cat-row">
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/cap.svg')" alt="">
          <span>Kacketi</span>
        </a>
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/tshirt.svg')" alt="">
          <span>Majice</span>
        </a>
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/shorts.svg')" alt="">
          <span>Sorcevi</span>
        </a>
      </div>
      <div class="cat-row">
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/hoodie.svg')" alt="">
          <span>Hoddie</span>
        </a>
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/socks.svg')" alt="">
          <span>Carape</span>
        </a>
        <a href="" class="cat-name">
          <img src="@asset('images/homepage/trousers.svg')" alt="">
          <span>Pantalone</span>
        </a>
      </div>
    </div>
  </div>
</section>